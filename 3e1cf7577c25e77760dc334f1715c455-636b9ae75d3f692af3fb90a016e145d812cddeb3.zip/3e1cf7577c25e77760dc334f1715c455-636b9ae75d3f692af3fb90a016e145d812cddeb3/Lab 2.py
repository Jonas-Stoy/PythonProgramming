print("Welcome to Jonas's program")
print("I am from Kansas City MO but I was raised in Arkansas City KS")
print(3 * 4 * 5)
print(44 // 3)
print(44 % 3)
print("Age=18")
print("job_title = 'cart pusher'")
print('\u03bb' + "Greek small letter lambda")
print('\u261e' + "Big finger arrow")
print('\u21ac' + "Fancy arrow")
print('\u1F31f' + "Star with flashing lights on it")
print('\u2721' + "Star of David")
print('\u1f320' + "Shooting Star")
print(21, 4*32, "hello")
x = 31
print(x, bin(x), hex(x))
x = 18
y = 0b1011
z = 0xA3
print(y, z)
w = x + y + z
print("the sum is", w)
